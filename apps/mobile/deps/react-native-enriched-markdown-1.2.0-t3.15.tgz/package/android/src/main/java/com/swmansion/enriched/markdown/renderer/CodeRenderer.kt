package com.swmansion.enriched.markdown.renderer

import android.text.SpannableStringBuilder
import android.text.TextPaint
import android.text.style.MetricAffectingSpan
import com.swmansion.enriched.markdown.parser.MarkdownASTNode
import com.swmansion.enriched.markdown.spans.CodeBackgroundSpan
import com.swmansion.enriched.markdown.spans.CodeSpan
import com.swmansion.enriched.markdown.utils.text.span.SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE

class CodeRenderer(
  private val config: RendererConfig,
) : NodeRenderer {
  override fun render(
    node: MarkdownASTNode,
    builder: SpannableStringBuilder,
    onLinkPress: ((String) -> Unit)?,
    onLinkLongPress: ((String) -> Unit)?,
    factory: RendererFactory,
  ) {
    if (node.children.isEmpty() || node.children.all { it.content.isEmpty() }) return

    factory.renderWithSpan(builder, { node.children.forEach { builder.append(it.content) } }) { start, end, blockStyle ->
      if (config.style.codeStyle.plainValueRegex?.matches(builder.subSequence(start, end)) == true) {
        builder.setSpan(TabularNumbersSpan(), start, end, SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE)
        return@renderWithSpan
      }

      builder.setSpan(
        CodeSpan(factory.styleCache, blockStyle),
        start,
        end,
        SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE,
      )
      builder.setSpan(
        CodeBackgroundSpan(config.style),
        start,
        end,
        SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE,
      )
    }
  }
}

private class TabularNumbersSpan : MetricAffectingSpan() {
  override fun updateDrawState(tp: TextPaint) = applyTabularNumbers(tp)
  override fun updateMeasureState(tp: TextPaint) = applyTabularNumbers(tp)

  private fun applyTabularNumbers(paint: TextPaint) {
    val features = paint.fontFeatureSettings
    paint.fontFeatureSettings = if (features.isNullOrEmpty()) "'tnum'" else "$features, 'tnum'"
  }
}
